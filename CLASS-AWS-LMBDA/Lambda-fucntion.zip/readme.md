```commandline
python3 -m venv venv
```

## On Linux / macOS:
```commandline
source venv/bin/activate
```

```commandline
pip install -r requirements.txt
```